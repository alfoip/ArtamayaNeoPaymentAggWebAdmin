(function($) {
	
	const ps2 = new PerfectScrollbar('.chat-scroll', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});
	const ps3 = new PerfectScrollbar('.Notification-scroll', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});
	const ps31 = new PerfectScrollbar('.text-scroll', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});
	const ps32 = new PerfectScrollbar('.notify-scroll', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});
	
	
})(jQuery);